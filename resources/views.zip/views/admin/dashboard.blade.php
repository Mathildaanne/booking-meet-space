@extends('layouts.admin')

@section('title', 'Dashboard Admin')

@section('content')
    <div class="row">
        <div class="col-md-4">
            <div class="card text-bg-primary mb-3">
                <div class="card-body">
                    <h5 class="card-title">Total Booking Hari Ini</h5>
                    <p class="card-text display-6">{{ $todayBooking }}</p>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card text-bg-success mb-3">
                <div class="card-body">
                    <h5 class="card-title">Total Ruangan</h5>
                    <p class="card-text display-6">{{ $totalRuangan }}</p>
                </div>
            </div>
        </div>
    </div>

    <div class="mt-4">
        <a href="{{ route('admin.ruang.index') }}" class="btn btn-outline-primary">
            🛠 Kelola Ruangan
        </a>

        <a href="{{ route('admin.booking.index') }}" class="btn btn-outline-secondary">
            📅 Lihat Booking
        </a>

        <a href="{{ route('admin.laporan.index') }}" class="btn btn-outline-success">
            📊 Laporan Booking
        </a>
        <a href="{{ route('admin.karyawan.index') }}" class="btn btn-outline-primary">
            🛠 Kelola Karyawan
        </a>
    </div>

    <div class="card mt-4 p-4 shadow">
    <h5 class="mb-3">Statistik Booking Tahunan</h5>
    <canvas id="adminBookingChart" height="100"></canvas>
</div>

<script>
    const ctx = document.getElementById('adminBookingChart').getContext('2d');
    const adminBookingChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'],
            datasets: [{
                label: 'Total Booking',
                data: @json($chartData),
                backgroundColor: 'rgba(16, 185, 129, 0.5)',
                borderColor: 'rgba(5, 150, 105, 1)',
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: { stepSize: 1 }
                }
            }
        }
    });
</script>


@endsection
