@extends('layouts.app')

@section('title', 'Dashboard')

@section('content')
<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
    <div class="bg-white rounded-lg shadow p-5 border border-gray-200">
        <div class="text-xs font-semibold text-gray-400 mb-1">Date - Time</div>
        <div class="text-sm font-semibold text-gray-900">Juli 08, 2025</div>
        <div class="text-xs text-gray-400 border-t border-gray-300 mt-2 pt-2">13.00 PM</div>
    </div>
    <div class="bg-white rounded-lg shadow p-5 border border-gray-200">
        <div class="text-xs font-semibold text-gray-400 mb-1">Jumlah Booking</div>
        <div class="flex items-center gap-2 text-blue-600 font-semibold text-2xl">
            <i class="fas fa-chair"></i> 10
        </div>
    </div>
</div>

<div class="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-6">
    <div class="lg:col-span-2 bg-white rounded-lg shadow p-5 border border-gray-200">
        <div class="text-xs font-semibold text-gray-600 mb-3">Meeting Statistics</div>
        <img src="https://storage.googleapis.com/a1aa/image/b7a14dea-4edf-4017-3693-1e626ef55ea4.jpg" class="w-full h-auto" alt="Stats">
    </div>
    <div class="bg-white rounded-lg shadow p-5 border border-gray-200">
        <div class="text-xs font-semibold text-gray-600 mb-3">Upcoming Schedule</div>
        <ul class="space-y-3 text-sm text-gray-700">
            <li class="flex items-center gap-3">
                <div class="w-8 h-8 flex justify-center items-center rounded border border-blue-600 text-blue-600">
                    <i class="fas fa-file-alt text-xs"></i>
                </div>
                <div>
                    <span class="font-semibold text-blue-600 hover:underline">Marketing Plan</span>
                    <div class="text-xs text-gray-400">14.00</div>
                </div>
            </li>
            <li class="flex items-center gap-3">
                <div class="w-8 h-8 flex justify-center items-center rounded border border-blue-600 text-blue-600">
                    <i class="fas fa-file-alt text-xs"></i>
                </div>
                <div>
                    <span class="font-semibold text-blue-600 hover:underline">Marketing Plan</span>
                    <div class="text-xs text-gray-400">15.00</div>
                </div>
            </li>
        </ul>
    </div>
</div>
@endsection
