@extends('layouts.user')

@section('title', 'Ajukan Booking')

@section('content')
<div class="container mt-4">
    <h2>Ajukan Booking - {{ $ruang->nama }}</h2>

    <form method="POST" action="{{ route('bookings.store') }}">
        @csrf
        <input type="hidden" name="ruang_id" value="{{ $ruang->id }}">

        <div class="mb-3">
            <label for="booking_date" class="form-label">Tanggal Booking</label>
            <input type="date" name="booking_date" class="form-control" value="{{ old('booking_date') }}" required>
        </div>

        <div class="mb-3">
            <label for="start_time" class="form-label">Jam Mulai</label>
            <input type="time" name="start_time" class="form-control" value="{{ old('start_time') }}" required>
        </div>

        <div class="mb-3">
            <label for="end_time" class="form-label">Jam Selesai</label>
            <input type="time" name="end_time" class="form-control" value="{{ old('end_time') }}" required>
        </div>

        <button type="submit" class="btn btn-primary">Ajukan Booking</button>
        <a href="{{ route('bookings.index') }}" class="btn btn-secondary">Batal</a>
    </form>
</div>
@endsection
