@extends('layouts.user')

@section('title', 'Booking Ruang Meeting')

@section('content')
<div class="container mt-4">
    <h2 class="mb-4">Booking Ruang Meeting</h2>

    <div class="row">
        @foreach ($ruangans as $ruang)
        <div class="col-md-6 mb-4">
            <div class="card shadow-sm">
                <img src="{{ asset('storage/' . $ruang->foto) }}" class="card-img-top" alt="{{ $ruang->nama }}" style="height:200px; object-fit:cover;">
                <div class="card-body">
                    <h5 class="card-title">{{ $ruang->nama }}</h5>
                    <p class="card-text">
                        Kapasitas: {{ $ruang->kapasitas }} orang <br>
                        Fasilitas: {{ $ruang->fasilitas }} <br>
                        Lantai: {{ $ruang->lantai ?? '-' }}
                    </p>
                    <a href="{{ route('jadwal.show', $ruang->id) }}" class="btn btn-sm btn-outline-success">Lihat Jadwal</a>
                    <a href="{{ route('booking.create', ['ruang' => $ruang->id]) }}" class="btn btn-sm btn-primary">Booking</a>
                </div>
            </div>
        </div>
        @endforeach
    </div>
</div>
@endsection
