@extends('layouts.user')

@section('title', 'Dashboard')

@section('content')
<!-- Ruangan Populer -->
<div 
    class="mb-6 shadow text-white -mx-6 mx-10 px-6"
    style="background-image: url('{{ asset('images/06.png') }}'); min-height: 150px; background-size: cover; background-position: center;"
>
    <div class="relative z-10 p-6">
        <h3 class="text-2xl font-bold">Hello {{ Auth::user()->nama }}! 👋</h3>
        <p class="text-sm">Selamat Datang di Meet Space</p>
    </div>
</div>




<div class="grid grid-cols-1 md:grid-cols-2 gap-4">
    <!-- Date & Total Booking -->
    <div class="bg-blue-600 text-white p-6 rounded-lg shadow">
        <p class="text-lg">Tanggal Hari Ini</p>
        <p class="text-2xl font-bold">{{ now()->format('l, d M Y') }}</p>
    </div>

    <div class="bg-green-600 text-white p-6 rounded-lg shadow">
        <p class="text-lg">Jumlah Booking Anda</p>
        <p class="text-4xl font-bold">{{ $jumlahBooking }}</p>
    </div>

    <!-- Schedule -->
    <div class="bg-white p-6 rounded-lg shadow col-span-2">
        <h2 class="text-xl font-semibold mb-2">Upcoming Schedule</h2>
        @if($upcoming)
            <p>{{ $upcoming->ruang->nama }} | {{ $upcoming->booking_date }} {{ $upcoming->start_time }} - {{ $upcoming->end_time }}</p>
        @else
            <p class="text-gray-500 italic">Belum ada jadwal mendatang</p>
        @endif
    </div>

    <!-- Cara Booking -->
    <div class="bg-white p-6 rounded-lg shadow col-span-2">
        <h2 class="text-xl font-semibold mb-2">Tata Cara Melakukan Booking</h2>
        <ol class="list-decimal list-inside text-gray-700">
            <li>Pilih menu <strong>Booking</strong></li>
            <li>Pilih ruangan yang diinginkan</li>
            <li>Tentukan tanggal dan waktu</li>
            <li>Submit dan tunggu konfirmasi</li>
        </ol>
    </div>
</div>
<!-- Statistik Booking -->
<div class="bg-white p-6 rounded-lg shadow col-span-2">
    <h2 class="text-xl font-semibold mb-4">Statistik Booking Anda ({{ now()->year }})</h2>
    <canvas id="bookingChart" height="100"></canvas>
</div>

<script>
    const ctx = document.getElementById('bookingChart').getContext('2d');
    const bookingChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'],
            datasets: [{
                label: 'Jumlah Booking',
                data: @json($chartData),
                backgroundColor: 'rgba(59, 130, 246, 0.2)',
                borderColor: 'rgba(59, 130, 246, 1)',
                borderWidth: 2,
                tension: 0.3,
                fill: true,
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true,
                    stepSize: 1
                }
            }
        }
    });
</script>

@endsection
