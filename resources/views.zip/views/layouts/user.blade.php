<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>@yield('title', 'Dashboard User')</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/@headlessui/react@1.4.2/dist/headlessui.umd.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js" defer></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-100 text-gray-800">
<div class="flex min-h-screen">
    <!-- Sidebar -->
    <aside class="w-64 bg-white shadow-lg"> <!-- shadow upgraded -->
        <div class="flex items-center p-4 border-b border-gray-200 shadow-sm">
            <img src="{{ asset('images/logo.png') }}" alt="Logo" class="w-8 h-8 mr-3"> <!-- Logo -->
            <span class="text-2xl font-bold text-blue-800">Meet Space</span>
        </div>
        <nav class="p-4" x-data="{ openBooking: false }">
            <a href="{{ route('user.dashboard') }}" class="flex items-center py-2 px-4 rounded hover:bg-blue-100">
                <i class="fas fa-home w-5 mr-3"></i> Dashboard
            </a>
            <!-- Booking Dropdown -->
            <button @click="openBooking = !openBooking" class="flex items-center justify-between w-full py-2 px-4 rounded hover:bg-blue-100 focus:outline-none">
                <div class="flex items-center">
                    <i class="fas fa-calendar-check w-5 mr-3"></i> Booking
                </div>
                <i :class="openBooking ? 'fa-chevron-up' : 'fa-chevron-down'" class="fas text-sm"></i>
            </button>
            <div x-show="openBooking" class="pl-8 mt-1 space-y-1">
                <a href="{{ route('bookings.index') }}" class="block py-1 px-2 rounded hover:bg-blue-50 text-sm">Booking Ruang</a>
                <a href="#" class="block py-1 px-2 rounded hover:bg-blue-50 text-sm">Calendar</a>
                <a href="{{ route('jadwal.index') }}" class="block py-1 px-2 rounded hover:bg-blue-50 text-sm">Jadwal</a>
            </div>

            <a href="#" class="flex items-center py-2 px-4 mt-2 rounded hover:bg-blue-100">
                <i class="fas fa-history w-5 mr-3"></i> Riwayat
            </a>
            <a href="#" class="flex items-center py-2 px-4 rounded hover:bg-blue-100">
                <i class="fas fa-users w-5 mr-3"></i> Users
            </a>
            <a href="#" class="flex items-center py-2 px-4 rounded hover:bg-blue-100">
                <i class="fas fa-table w-5 mr-3"></i> Table
            </a>

            <!-- Logout -->
            <form method="POST" action="{{ route('logout') }}" class="mt-4">
                @csrf
                <button class="flex items-center w-full py-2 px-4 text-red-600 rounded hover:bg-red-100">
                    <i class="fas fa-sign-out-alt w-5 mr-3"></i> Logout
                </button>
            </form>
        </nav>
    </aside>

    <!-- Main Content -->
    <div class="flex-1 flex flex-col">
        <!-- Topbar -->
        <!-- Topbar -->
        <header class="flex items-center justify-between px-4 py-3 bg-white shadow-md">
            <!-- Center: Search -->
            <div class="hidden md:flex flex-1 justify-center px-4">
                <div class="relative w-full max-w-md">
                    <input
                        type="text"
                        placeholder="Search..."
                        class="w-full pl-10 pr-4 py-2 rounded-md border border-gray-300 focus:ring focus:ring-blue-100 focus:outline-none"
                    >
                    <i class="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                </div>
            </div>

            <!-- Right: User Info -->
            <div class="flex items-center space-x-3">
                <img src="https://i.pravatar.cc/40?img=3" class="w-10 h-10 rounded-full" alt="User">
                <div class="hidden md:block text-right">
                    <div class="text-sm font-medium">Austin Robertson</div>
                    <div class="text-xs text-gray-500">Marketing Administrator</div>
                </div>
            </div>
        </header>

        <!-- Page Content -->
        <main class="flex-1 p-6 bg-gray-50">
            @yield('content')
        </main>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</body>
</html>
